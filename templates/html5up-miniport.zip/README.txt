Miniport 2.5 by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)


A super simple responsive portfolio template. It's only a single page because hey, sometimes
you don't need a half dozen pages to make your point.

Feedback, bug reports, and comments are not only welcome, but strongly encouraged :)

AJ
n33.co @n33co dribbble.com/n33


Credits:

	Images:
		fotogrph (http://fotogrph.com/)
		n33 (http://flypixel.com/n33)
	
	Other:
		jQuery (jquery.com)
		html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		skelJS (skeljs.org)